from django.apps import AppConfig


class PickerConfig(AppConfig):
    name = 'picker'
